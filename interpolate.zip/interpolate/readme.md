### Interpolate the Intensity and Number Density

#### INPUT
1. mesh.txt
The mesh on which to interpolate and save the data
2. parameters.inp
Numbers of cell centers in x and in y in the mesh provided in a column
3. Profile Data files (I_Pulse2_0 , Rho_e_0 )

#### Output 
1. out_10 file where the number at the end denotes the time